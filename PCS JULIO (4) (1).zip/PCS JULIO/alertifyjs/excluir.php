﻿<?php
	$id= $_GET["id"];
	$nome = $_GET["nome"];
	if (ISSET($_POST['SIM'])){
		$sql = "DELETE 
				FROM listaatividades
				WHERE idAtividade = $id";
		include "conexao.php";
		$contato = $gol -> prepare($sql);
		$contato -> execute();
		$gol = NULL;
		header ("location: index.php");	
	}
?>
<html lang="PT-BR">
<head>
	<body>
		<h2>
			Excluir <?php echo $nome; ?> ?
		</h2>
	</body>
	<form action="#" method="POST">
		<input type="button" value="Não" onclick="Javascript: window.history.back();">&nbsp;
		<input type="submit" value="Sim" name="SIM"> 
	</form>
</head>
</html>