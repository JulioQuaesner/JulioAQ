﻿<!DOCTYPE html>
<?PHP
    $id = $_GET['id'];
    $sql= "SELECT * FROM listaatividades WHERE idAtividade = $id";
	include "conexao.php";
    $contatos = $gol -> prepare($sql);
    $contatos -> execute();
	
	foreach($contatos as $bolacha){}
	if (ISSET($_POST['salvar'])){
		$nome = $_POST['nomeUsuario'];
		$Fazer = $_POST['Fazer'];
		$Fazendo = $_POST['Fazendo'];
		$Feito = $_POST['Feito'];
		$sql = "UPDATE listaatividades
				SET
				nomeUsuario = '$nome',
				Fazer = '$Fazer',
				Fazendo = '$Fazendo',
				Feito = '$Feito'				
				WHERE
				idAtividade = '$id'
		";
	$contato = $gol -> prepare($sql);
	$contato -> execute();		
	$gol = null;
	header("Location: index.php");	
	}	
?>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">
		<title>Tarefas</title>
	</head>
	<body>
		<hr><center>
		<h2>Lista de tarefas</h2>
		<hr></center>
		<form action="#" method="POST">
			Nome do usuário:<br>
			<input type="text" name="nomeUsuario" value="<?php echo $bolacha['nomeUsuario'];?>"><br><br>
			Fazer:<br>
			<input type="text" name="Fazer"value="<?php echo $bolacha['Fazer'];?>"><br><br>
			Fazendo:<br>
			<input type="text" name="Fazendo" value="<?php echo $bolacha['Fazendo'];?>"><br><br>
			Feito:<br>
			<input type="text" name="Feito" value="<?php echo $bolacha['Feito'];?>"><br><br>
			<input type="submit" value="Salvar" name="salvar">
		</form>
	</body>
</html>	