<?php  
    include "conexao.php";
	$sql = "SELECT * FROM listaAtividades ORDER BY Fazer";
	$dados = $gol -> prepare($sql);
	$dados -> execute();
	$gol = null; 
?>

<!DOCTYPE html>
<html lang="pt-br"> 
    <head>
	    <meta charset="UTF-8">
		<title>Lista de atividades</title>
	</head>
	<body>
	   <hr>
	   <h2>Listar atividades <h2>
	   <hr>
	   <a href="inserir.php"><button>Inserir</button></a>
	 
	   <table border="1">
	      <tr>
		    <th>nomeUsuario</th>
			<th>Fazer</th>
			<th>Fazendo</th>
			<th>Feito</th>
			
		 </tr>
	   <?php 
	     foreach($dados as $bolacha){
			$nomeUsuario =$bolacha['nomeUsuario'];
	        $Fazer = $bolacha['Fazer'];
	        $Fazendo = $bolacha['Fazendo'];
	        $Feito = $bolacha['Feito'];
			
			
			
			echo "<tr>";
			echo "<td>".$nomeUsuario."</td>";
			echo "<td>".$Fazer."</td>";
			echo "<td>".$Fazendo."</td>";
			echo "<td>".$Feito."</td>";
			
		    echo "<td align='center'>
			<a href='agenda_editar.php?id=$nomeUsuario&nome=$Fazer'>
			<img src='imagens/editar.png' width='25px' title='Editar $Fazer'>
			
			</a>
			
			<a href='agenda_excluir.php?id=$nomeUsuario&nome=$Fazer'>
			<img src='imagens/lixeirabatman.jpg' width='25px' title='Excluir $Fazer'>
			
			</a>
			</td>";
			echo "</tr>";
			
			
		 }	   
	   ?>
	   </table>
	   
	   <meta name="viewport" content="width=device-width, initial-scale=1">
	  <title>jQuery UI Datepicker - Format date</title>
	  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	  <link rel="stylesheet" href="/resources/demos/style.css">
	  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	  <script>
	  $( function() {
		$( "#datepicker" ).datepicker();
		$( "#format" ).on( "change", function() {
		  $( "#datepicker" ).datepicker( "option", "dateFormat", $( this ).val() );
		});
	  } );
	  </script>
	  
	  <p>Date: <input type="text" id="datepicker" size="30"></p>
 
<p>Format options:<br>
  <select id="format">
    <option value="mm/dd/yy">Default - mm/dd/yy</option>
    <option value="yy-mm-dd">ISO 8601 - yy-mm-dd</option>
    <option value="d M, y">Short - d M, y</option>
    <option value="d MM, y">Medium - d MM, y</option>
    <option value="DD, d MM, yy">Full - DD, d MM, yy</option>
    <option value="&apos;day&apos; d &apos;of&apos; MM &apos;in the year&apos; yy">With text - 'day' d 'of' MM 'in the year' yy</option>
  </select>
</p>
 

 


<link href="preload/preloader.css" rel="stylesheet">



    
<!-- include alertify.css -->
<link rel="stylesheet" href="css/alertify.css">
<link rel="stylesheet" href="css/microtip.css">



<!-- include semantic ui theme  -->
<link rel="stylesheet" href="{PATH}/themes/semantic.css">

<!-- include alertify script -->
<script src="alertify.js"></script>

<script type="text/javascript">  
function alertar(){
alertify.minimalDialog || alertify.dialog('minimalDialog',function(){
    return {
        main:function(content){
            this.setContent(content); 
        }
    };
});
alertify.minimalDialog("Minimal button-less dialog.");
}
  function toast(){
  alertify.message('Cartão adicionado com sucesso!');
  } 

  
 
//override defaults
alertify.defaults.transition = "zoom";
alertify.defaults.theme.ok = "ui positive button";
alertify.defaults.theme.cancel = "ui black button";
</script>      

	<input type="button" value="Carregar" onclick="alertar()";/>
	<button aria-label="Hello, World!" data-microtip-position="up" role="tooltip">
	<input type="button" value="Toast" onclick="toast()";/>
	<script src="preload/preloader.js"></script>
  </body>
</html> 