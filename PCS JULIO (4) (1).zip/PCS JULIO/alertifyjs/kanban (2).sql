-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 20-Abr-2019 às 19:17
-- Versão do servidor: 10.1.36-MariaDB
-- versão do PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanban`
--
CREATE DATABASE IF NOT EXISTS `kanban` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kanban`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `listaatividades`
--

CREATE TABLE `listaatividades` (
  `id_atividade` int(6) NOT NULL,
  `nomeUsuario` varchar(50) NOT NULL,
  `Fazer` varchar(180) NOT NULL,
  `Fazendo` varchar(180) NOT NULL,
  `Feito` varchar(180) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `listaatividades`
--

INSERT INTO `listaatividades` (`id_atividade`, `nomeUsuario`, `Fazer`, `Fazendo`, `Feito`) VALUES
(1, '', 'Diagrama de sequÃªncia', '3D', ''),
(2, '', 'DocumentaÃ§Ã£o', 'Diagrama de classes', 'Modelagem do site'),
(3, '', 'DocumentaÃ§Ã£o', 'DER', ''),
(4, '', 'Diagrama de sequÃªncia', 'Design Pattern', '3D'),
(5, 'Frank', 'Design Pattern', 'Diagrama de classes', 'DocumentaÃ§Ã£o');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `listaatividades`
--
ALTER TABLE `listaatividades`
  ADD PRIMARY KEY (`id_atividade`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `listaatividades`
--
ALTER TABLE `listaatividades`
  MODIFY `id_atividade` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
