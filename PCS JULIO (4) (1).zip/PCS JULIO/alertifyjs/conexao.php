﻿<?php
  try{ //tente
     $gol = new PDO("mysql:host=localhost; dbname=kanban; charset=utf8","root","");
	 
	 echo "Conexão efetuada com sucesso!!!";  
  }
  catch  (PDOException $e){ //Bloco correspondente ao try
        //testar var_dump($e);
		// teste método echo $e->getCode();
		echo $e->getMessage(); //método amplamente utilizado
	}
?>