<!DOCTYPE html>
<?PHP
   if(ISSET($_POST["salvar"])){
	 $nomeUsuario = $_POST["nomeUsuario"]; 
	 $Fazer = $_POST["Fazer"];  
	 $Fazendo = $_POST["Fazendo"];  
	 $Feito = $_POST["Feito"];  
	
	echo $id_atividade;
	echo $nomeUsuario;
	echo $Fazer;
	echo $Fazendo;
	echo $Feito;
	 
	 $sql="INSERT INTO listaAtividades
	 (idAtividade, nomeUsuario, Fazer, Fazendo, Feito)
	  VALUES
	 ('$idAtividade','$nomeUsuario', '$Fazer','$Fazendo','$Feito')";
	 include "conexao.php";
     $dados = $gol -> prepare($sql);
	 $dados -> execute();
	 $gol = NULL;
	 header("Location:index.php");
   }
?>   
<html lang="pt-br">
   <head>
      <meta charset="UTF-8">
	  <title>Lista de atividades do usuário</title>
	</head>
	<body>
	  <hr>
	    <form action="#" method="POST">
		  Nome do usuário:<br>
		 <input type="text" name="nomeUsuario" autofocus><br>
		 <br>
		  Fazer:<br>
		 <input type="text" name="Fazer"><br>
		 <br>
		 Fazendo:<br>
		 <input type="text" name="Fazendo"><br>
		 <br>
		 Feito:<br>
		 <input type="text" name="Feito"><br>
		 <br>
		  <input type="submit" value="Salvar" name="salvar">
		 </form>
</body>
</html>	