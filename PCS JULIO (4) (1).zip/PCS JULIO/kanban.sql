-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 21-Abr-2019 às 01:15
-- Versão do servidor: 10.3.12-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanban`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `listaatividades`
--

CREATE TABLE `listaatividades` (
  `idAtividade` int(10) NOT NULL,
  `nomeUsuario` varchar(50) DEFAULT NULL,
  `Fazer` varchar(180) DEFAULT NULL,
  `Fazendo` varchar(180) DEFAULT NULL,
  `Feito` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `listaatividades`
--

INSERT INTO `listaatividades` (`idAtividade`, `nomeUsuario`, `Fazer`, `Fazendo`, `Feito`) VALUES
(1, 'Julio Augusto', 'Escolher nome do projeto', 'Quadro no Trello', 'Login');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `listaatividades`
--
ALTER TABLE `listaatividades`
  ADD PRIMARY KEY (`idAtividade`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `listaatividades`
--
ALTER TABLE `listaatividades`
  MODIFY `idAtividade` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
